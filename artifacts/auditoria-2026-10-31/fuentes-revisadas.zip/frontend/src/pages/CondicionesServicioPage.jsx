import LegalLayout from '../components/layout/LegalLayout';
import useSeo from '../hooks/useSeo';
import { MailCheck } from 'lucide-react';

const TOC_ITEMS = [
  { id: 'seccion-1', label: '1. Alcance de los Servicios' },
  { id: 'seccion-2', label: '2. Planes y Suscripciones' },
  { id: 'seccion-3', label: '3. Facturación y Pasarelas de Pago' },
  { id: 'seccion-4', label: '4. Recepción de Facturas (Cloudflare y WhatsApp)' },
  { id: 'seccion-5', label: '5. Facturación Electrónica REA' },
  { id: 'seccion-6', label: '6. Límites Operativos y SLA' },
  { id: 'seccion-7', label: '7. Cancelación y Reembolsos' },
  { id: 'seccion-8', label: '8. Soporte al Cliente' },
];

export default function CondicionesServicioPage() {
  useSeo({
    title: 'Condiciones del Servicio | ContadorGanadero Costa Rica',
    description: 'Condiciones de servicio, planes freemium/pro, pagos e integraciones de ContadorGanadero para productores agropecuarios.',
    path: '/condiciones-servicio',
    robots: 'index, follow',
  });

  return (
    <LegalLayout
      title="Condiciones del Servicio (SLA y Planes)"
      subtitle="Detalles operativos sobre planes de suscripción, recepción de facturas por correo Cloudflare y WhatsApp, facturación electrónica REA y procesamiento de datos."
      badgeText="Condiciones Operativas"
      badgeType="amber"
      tocItems={TOC_ITEMS}
    >
      {/* Sección 1 */}
      <section id="seccion-1" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">01.</span>
          <h2 className="legal-section-title">Alcance de los Servicios Prestados</h2>
        </div>
        <p>
          ContadorGanadero pone a disposición del usuario un conjunto de herramientas modulares en la nube diseñadas para
          el sector agropecuario costarricense:
        </p>
        <ul>
          <li><strong>Importación y Lectura de Facturas:</strong> Recepción instantánea y extracción automática de datos de archivos XML y PDF de facturas electrónicas mediante buzón exclusivo Cloudflare (<code>@contadorganandero.com</code>) y bot oficial de WhatsApp.</li>
          <li><strong>Categorización Asistida por IA:</strong> Clasificación inteligente de insumos (alimentos, medicamentos veterinarios, sal, agroquímicos, maquinaria).</li>
          <li><strong>Módulos de Inventario Productivo:</strong> Control de ganado bovino (pesaje, ganancia diaria), aves de postura (lotes, mortalidad), acuicultura (biomasa, FCA) y apicultura (cosechas de miel).</li>
          <li><strong>Costos de Producción y Rentabilidad:</strong> Cálculo del costo real por kilogramo de carne, cartón de huevos o unidad de producto cosechado.</li>
          <li><strong>Proyecciones Tributarias REA:</strong> Estimación del IVA Cuatrimestral (D-135-1), Renta Anual (D-101) y resumen informativo D-150.</li>
        </ul>
      </section>

      {/* Sección 2 */}
      <section id="seccion-2" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">02.</span>
          <h2 className="legal-section-title">Planes y Modelos de Suscripción</h2>
        </div>
        <p>
          ContadorGanadero opera bajo un modelo freemium con dos planes simples:
        </p>
        <ul>
          <li>
            <strong>Plan Gratis (Con Anuncios):</strong> Acceso a módulos fundamentales para pequeños productores, sostenido mediante publicidad de Google AdSense. Incluye recepción de facturas por correo y WhatsApp, y cuota básica de procesamiento mensual con IA.
          </li>
          <li>
            <strong>Plan Pro ($10/mes, Sin Anuncios):</strong> Eliminación total de publicidad de Google AdSense, mayor cuota de procesamiento de facturas, conteos por visión computacional (VLM), módulo D-150 / conciliación anual REA, más almacenamiento y soporte por email.
          </li>
        </ul>
      </section>

      {/* Sección 3 */}
      <section id="seccion-3" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">03.</span>
          <h2 className="legal-section-title">Facturación, Precios y Pasarelas de Pago</h2>
        </div>
        <p>
          Los pagos de la suscripción paga (Plan Pro) se procesan a través de la pasarela segura <strong>ONVO Pay</strong>.
        </p>
        <ul>
          <li><strong>Ciclos de Cobro:</strong> Las suscripciones se cobran por adelantado en ciclos mensuales o anuales, según la opción seleccionada.</li>
          <li><strong>Renovación Automática:</strong> Salvo que cancele su suscripción antes de la fecha de vencimiento, la suscripción se renovará automáticamente usando el método de pago registrado.</li>
          <li><strong>Impuestos Aplicables:</strong> Las tarifas publicadas no incluyen el Impuesto sobre el Valor Agregado (IVA) correspondiente a servicios digitales transfronterizos o locales, el cual será desglosado en el checkout.</li>
        </ul>
      </section>

      {/* Sección 4 */}
      <section id="seccion-4" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">04.</span>
          <h2 className="legal-section-title">Recepción de Facturas (Correo Cloudflare y WhatsApp)</h2>
        </div>
        <p>
          Para facilitar el procesamiento de comprobantes electrónicos, cada finca dispone de una dirección de correo exclusiva (<code>@contadorganandero.com</code>) administrada mediante Cloudflare Email Routing, además de un bot de WhatsApp para el reenvío directo de facturas.
        </p>
        <div className="legal-alert legal-alert--info">
          <MailCheck size={22} className="legal-alert-icon" />
          <div className="legal-alert-content">
            <h4>Privacidad del Correo y Mensajería</h4>
            <p>
              Nuestro motor de ingesta analiza exclusivamente correos y mensajes que contengan comprobantes electrónicos con extensión <code>.xml</code> o <code>.pdf</code>
              correspondientes a facturas y acuses (MensajeHacienda). <strong>No leemos, almacenamos ni compartimos correspondencia personal o comercial ajena a la facturación tributaria.</strong>
            </p>
          </div>
        </div>
      </section>

      {/* Sección 5 */}
      <section id="seccion-5" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">05.</span>
          <h2 className="legal-section-title">Facturación Electrónica REA y Comunicación con Hacienda</h2>
        </div>
        <p>
          Para el módulo de emisión de comprobantes electrónicos bajo el Régimen Especial Agropecuario (tarifa 1% de IVA):
        </p>
        <ul>
          <li>El usuario es el único responsable de contar con inscripción activa ante el MAG y la Dirección General de Tributación (DGT).</li>
          <li>El usuario debe cargar su llave criptográfica oficial (archivo <code>.p12</code>) y PIN de 4 dígitos proporcionado por ATV Hacienda.</li>
          <li>ContadorGanadero almacena la llave de forma estrictamente cifrada para firmar los comprobantes XML en el momento de su emisión.</li>
        </ul>
      </section>

      {/* Sección 6 */}
      <section id="seccion-6" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">06.</span>
          <h2 className="legal-section-title">Límites Operativos y Disponibilidad del Servicio (SLA)</h2>
        </div>
        <p>
          Nos esforzamos por mantener una disponibilidad de servicio del <strong>99.5%</strong>. No obstante, pueden presentarse
          interrupciones por mantenimientos programados de la infraestructura o fallas en servicios de terceros (Google Cloud, OpenRouter, ATV Hacienda).
        </p>
        <p>
          Los planes cuentan con límites de llamadas a modelos de IA para evitar abusos y garantizar un rendimiento óptimo para toda la comunidad de productores.
        </p>
      </section>

      {/* Sección 7 */}
      <section id="seccion-7" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">07.</span>
          <h2 className="legal-section-title">Cancelación de Suscripciones y Política de Reembolsos</h2>
        </div>
        <p>
          Usted puede cancelar su suscripción al <strong>Plan Pro</strong> en cualquier momento, sin penalidad y sin
          necesidad de contactar a soporte, desde la sección <strong>Mi Suscripción</strong> de su panel, confirmando
          la acción en el diálogo de cancelación.
        </p>
        <ul>
          <li>
            <strong>Efecto de la cancelación:</strong> la cancelación se procesa de forma inmediata. Su cuenta pasa al
            <strong> Plan Gratis</strong> (con anuncios) en ese mismo momento y cesa el cobro recurrente ante ONVO Pay.
          </li>
          <li>
            <strong>Conservación de sus datos:</strong> sus facturas, ingresos, gastos, inventario y comprobantes XML se
            conservan y siguen disponibles en el Plan Gratis. La cancelación no elimina información ni historial contable.
          </li>
          <li>
            <strong>Cargos ya realizados:</strong> por la naturaleza digital y de consumo inmediato de los recursos de
            cómputo e IA, los cobros correspondientes al periodo en curso no son reembolsables, salvo error de cobro
            atribuible a la plataforma o cobro duplicado.
          </li>
          <li>
            <strong>Errores de cobro:</strong> si detecta un cobro duplicado, un monto incorrecto o un cargo posterior a
            su cancelación, escríbanos a <code>soporte@contadorganandero.com</code> dentro de los <strong>5 días hábiles</strong>
            siguientes al cargo. Verificaremos el caso con ONVO Pay y, de corresponder, emitiremos el reembolso por el
            mismo medio de pago utilizado.
          </li>
          <li>
            <strong>Renovaciones automáticas:</strong> la suscripción se renueva cada mes. Para evitar el cobro del ciclo
            siguiente, cancele antes de la fecha de renovación indicada en <strong>Mi Suscripción</strong>.
          </li>
          <li>
            <strong>Cambios de precio:</strong> cualquier modificación en el precio del Plan Pro se comunicará con al
            menos <strong>30 días</strong> de anticipación por correo electrónico. Si no está de acuerdo, podrá cancelar
            antes de que el nuevo precio entre en vigencia.
          </li>
        </ul>
        <p>
          Estas disposiciones se aplican sin perjuicio de los derechos que la Ley N.º 7472 (Ley de Promoción de la
          Competencia y Defensa Efectiva del Consumidor) y la Ley N.º 8968 reconozcan al usuario.
        </p>
        <div className="legal-alert legal-alert--info">
          <MailCheck size={22} className="legal-alert-icon" />
          <div className="legal-alert-content">
            <h4>Contacto para Facturación, Cobros y Reembolsos</h4>
            <p>
              Consultas sobre cobros, cancelaciones, reembolsos o facturación de la suscripción:
              <a href="mailto:soporte@contadorganandero.com" style={{ color: '#4ade80' }}> soporte@contadorganandero.com</a>.
              Respondemos en horario de días hábiles.
            </p>
          </div>
        </div>
      </section>

      {/* Sección 8 */}
      <section id="seccion-8" className="legal-section">
        <div className="legal-section-heading">
          <span className="legal-section-number">08.</span>
          <h2 className="legal-section-title">Soporte Técnico y Atención al Productor</h2>
        </div>
        <p>
          Ofrecemos soporte técnico continuo para resolver incidencias de acceso, recepción de facturas o dudas sobre la visualización de reportes:
        </p>
        <ul>
          <li><strong>Plan Gratis:</strong> Soporte vía asistente virtual con IA y comunidad.</li>
          <li><strong>Plan Pro:</strong> Soporte por correo electrónico en días hábiles.</li>
        </ul>
      </section>
    </LegalLayout>
  );
}
