import axios from 'axios';
import { resolverApiUrl } from './apiUrl';

export const API_URL = resolverApiUrl(import.meta.env);

// Access token efímero en memoria (nunca en localStorage ni sessionStorage para mitigar robo por XSS)
let inMemoryAccessToken = null;

export const setAccessToken = (token) => {
  inMemoryAccessToken = token || null;
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
  } catch {
    // ignorar en entornos sin storage
  }
};

export const getAccessToken = () => inMemoryAccessToken;

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true, // Necesario para que las cookies httpOnly del refresh token viajen
});

// Interceptor: agregar token JWT desde memoria
api.interceptors.request.use((config) => {
  if (inMemoryAccessToken) {
    config.headers.Authorization = `Bearer ${inMemoryAccessToken}`;
  }
  return config;
});

// Bandera para evitar múltiples refresh simultáneos
let refreshPromise = null;

// Interceptor: manejar errores 401 con refresh token transparente vía cookie httpOnly
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Si no es 401, o ya se marcó retry, o es ruta de auth, propagar
    const esRutaAuth = originalRequest?.url?.startsWith('/auth/');
    if (
      error.response?.status !== 401 ||
      originalRequest._retry ||
      esRutaAuth
    ) {
      return Promise.reject(error);
    }

    originalRequest._retry = true;

    try {
      if (!refreshPromise) {
        refreshPromise = api.post('/auth/refresh').finally(() => {
          refreshPromise = null;
        });
      }

      const res = await refreshPromise;
      const nuevoToken = res.data?.token;
      if (nuevoToken) {
        setAccessToken(nuevoToken);
        originalRequest.headers = originalRequest.headers || {};
        originalRequest.headers.Authorization = `Bearer ${nuevoToken}`;
      }
      return api(originalRequest);
    } catch (refreshErr) {
      try {
        await api.post('/auth/logout');
      } catch { /* cookie posiblemente ya no existe */ }
      setAccessToken(null);
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
      return Promise.reject(refreshErr);
    }
  }
);

// === Auth ===
export const loginAPI = (datos) => api.post('/auth/login', datos);
export const registroAPI = (datos) => api.post('/auth/registro', datos);
export const refreshTokenAPI = () => api.post('/auth/refresh');
export const obtenerPerfilAPI = () => api.get('/auth/perfil');
export const actualizarPerfilAPI = (datos) => api.put('/auth/perfil', datos);
export const cambiarPasswordAPI = (datos) => api.put('/auth/cambiar-password', datos);
export const forgotPasswordAPI = (datos) => api.post('/auth/forgot-password', datos);
export const resetPasswordAPI = (datos) => api.post('/auth/reset-password', datos);
export const mfaSetupAPI = () => api.post('/auth/mfa/setup');
export const mfaEnableAPI = (datos) => api.post('/auth/mfa/enable', datos);
export const mfaDisableAPI = (datos) => api.post('/auth/mfa/disable', datos);
export const listarSesionesAPI = () => api.get('/auth/sessions');
export const revocarSesionAPI = (sessionId) => api.delete(`/auth/sessions/${encodeURIComponent(sessionId)}`);
export const logoutAllAPI = () => api.post('/auth/logout-all');
export const exportarMisDatosAPI = () => api.get('/auth/exportar-datos');

// === Ingresos ===
export const obtenerIngresosAPI = (params) => api.get('/ingresos', { params });
export const crearIngresoAPI = (datos) => api.post('/ingresos', datos);
export const eliminarIngresoAPI = (id) => api.delete(`/ingresos/${id}`);

// === Facturas ===
export const obtenerFacturasAPI = (params) => api.get('/facturas', { params });
export const subirFacturaXML_API = (formData) => api.post('/facturas/upload', formData, {
  headers: { 'Content-Type': 'multipart/form-data' },
});

// === Descarga de archivos XML / PDF ===
async function descargarArchivo(url) {
  try {
    const res = await api.get(url, { responseType: 'blob' });
    return res;
  } catch (err) {
    if (err.response?.data instanceof Blob) {
      const texto = await err.response.data.text();
      try {
        const json = JSON.parse(texto);
        err.response.data = json;
      } catch { /* no era JSON */ }
    }
    throw err;
  }
}

export const descargarXML_API = (id) => descargarArchivo(`/facturas/${id}/xml`);
export const descargarPDF_API = (id) => descargarArchivo(`/facturas/${id}/pdf`);

// === Alertas de tarifa agropecuaria ===
export const obtenerAlertasTarifaAPI = () => api.get('/facturas/alertas-tarifa');

// === Gastos Manuales ===
export const crearGastoManualAPI = (datos) => api.post('/facturas/manual', datos);

// === Impuestos ===
export const calcularIVA_API = (cuatrimestre, anio) => api.get(`/impuestos/iva/${cuatrimestre}/${anio}`);
export const calcularRentaAPI = (anio) => api.get(`/impuestos/renta/${anio}`);

// === Declaraciones ===
export const obtenerConfigFiscalAPI = () => api.get('/declaraciones/configuracion');
export const actualizarConfigFiscalAPI = (datos) => api.put('/declaraciones/configuracion', datos);
export const obtenerResumenDeclaracionAPI = (params) => api.get('/declaraciones/resumen', { params });
export const obtenerGastosDeduciblesAPI = (params) => api.get('/declaraciones/gastos', { params });
export const obtenerIngresosDeclaracionAPI = (params) => api.get('/declaraciones/ingresos', { params });
export const exportarDatosAPI = (params) => api.get('/declaraciones/exportar', { params, responseType: 'blob' });

// CRUD declaraciones guardadas
export const listarDeclaracionesAPI = (params) => api.get('/declaraciones', { params });
export const generarDeclaracionAPI = (datos) => api.post('/declaraciones', datos);
export const actualizarEstadoDeclaracionAPI = (id, datos) => api.put(`/declaraciones/${id}/estado`, datos);
export const eliminarDeclaracionAPI = (id) => api.delete(`/declaraciones/${id}`);

// === Deducibilidad ===
export const actualizarDeducibilidadAPI = (id, datos) => api.put(`/facturas/${id}/deducibilidad`, datos);

// === ONVO Pay / SaaS ===
export const crearCheckoutAPI = (planId) => api.post('/onvo/checkout', { planId });
export const cancelarSuscripcionAPI = () => api.post('/onvo/cancelar');
export const obtenerEstadoSuscripcionAPI = () => api.get('/onvo/estado');
export const obtenerPlanesAPI = () => api.get('/onvo/planes');
export const logoutAPI = () => api.post('/auth/logout');

// === Dashboard ===
export const resumenDashboardAPI = () => api.get('/dashboard/resumen');
export const gastosPorCategoriaAPI = (anio) => api.get('/dashboard/gastos-por-categoria', { params: { anio } });
export const tendenciaMensualAPI = (anio) => api.get('/dashboard/tendencia-mensual', { params: { anio } });

// === Chat IA ===
export const chatAPI = (mensaje, historial) => api.post('/chat', { mensaje, historial });

/**
 * Chat con streaming SSE — retorna un ReadableStream.
 * Usa fetch directo para leer Server-Sent Events con credenciales y token en memoria.
 */
export const chatStreamAPI = async (mensaje, historial, onChunk, onDone, onError) => {
  const token = getAccessToken();
  const baseUrl = API_URL;

  try {
    const response = await fetch(`${baseUrl}/chat/stream`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ mensaje, historial }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      onError?.(errorData.respuesta || `Error ${response.status}`);
      return;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6).trim();
          if (data === '[DONE]') {
            onDone?.();
            return;
          }
          try {
            const parsed = JSON.parse(data);
            if (parsed.error) {
              onError?.(parsed.error);
              return;
            }
            if (parsed.contenido) {
              onChunk?.(parsed.contenido);
            }
            if (parsed.done) {
              onDone?.(parsed.requestId);
              return;
            }
          } catch {
            // Ignorar líneas no-JSON
          }
        }
      }
    }

    onDone?.();
  } catch (err) {
    if (err.name === 'AbortError') return;
    onError?.(err.message || 'Error de conexión con el asistente');
  }
};

// Feedback del chat
export const chatFeedbackAPI = (data) => api.post('/chat/feedback', data);

// === Inventario ===
export const obtenerInventarioAPI = () => api.get('/inventario');
export const obtenerResumenInventarioAPI = () => api.get('/inventario/resumen');
export const agregarBovinoAPI = (datos) => api.post('/inventario/bovinos', datos);
export const actualizarBovinoAPI = (id, datos) => api.put(`/inventario/bovinos/${id}`, datos);
export const eliminarBovinoAPI = (id) => api.delete(`/inventario/bovinos/${id}`);
export const agregarLoteAvesAPI = (datos) => api.post('/inventario/aves', datos);
export const actualizarLoteAvesAPI = (id, datos) => api.put(`/inventario/aves/${id}`, datos);
export const eliminarLoteAvesAPI = (id) => api.delete(`/inventario/aves/${id}`);
export const agregarEstanqueAPI = (datos) => api.post('/inventario/peces', datos);
export const actualizarEstanqueAPI = (id, datos) => api.put(`/inventario/peces/${id}`, datos);
export const eliminarEstanqueAPI = (id) => api.delete(`/inventario/peces/${id}`);
export const agregarColmenaAPI = (datos) => api.post('/inventario/colmenas', datos);
export const actualizarColmenaAPI = (id, datos) => api.put(`/inventario/colmenas/${id}`, datos);
export const eliminarColmenaAPI = (id) => api.delete(`/inventario/colmenas/${id}`);

// === Costos de Producción ===
export const obtenerResumenCostosAPI = (params) => api.get('/costos/resumen', { params });

// === Facturación Electrónica REA ===
export const obtenerFacturasEmisionAPI = (params) => api.get('/facturacion', { params });
export const crearFacturaEmisionAPI = (datos) => api.post('/facturacion', datos);
export const obtenerResumenEmisionAPI = (params) => api.get('/facturacion/resumen', { params });

// === Hacienda v4.4 nativa ===
export const infoAmbienteHaciendaAPI = () => api.get('/hacienda/ambiente');
export const crearBorradorHaciendaAPI = (datos) => api.post('/hacienda/emision', datos);
export const firmarDocumentoHaciendaAPI = (id) => api.post(`/hacienda/emision/${id}/firmar`);
export const enviarAHaciendaAPI = (id) => api.post(`/hacienda/emision/${id}/enviar`);
export const consultarEstadoHaciendaAPI = (id) => api.get(`/hacienda/emision/${id}/estado`);
export const cancelarDocumentoHaciendaAPI = (id) => api.post(`/hacienda/emision/${id}/cancelar`);
export const descargarXmlHaciendaAPI = (id) => descargarArchivoBlob(`/hacienda/emision/${id}/xml`);

// REP (Recibo Electronico de Pago)
export const crearRepAPI = (datos) => api.post('/hacienda/rep', datos);
export const listarRepAPI = (params) => api.get('/hacienda/rep', { params });

// FEC (Factura Electronica de Compra)
export const crearFecAPI = (datos) => api.post('/hacienda/fec', datos);
export const listarFecAPI = (params) => api.get('/hacienda/fec', { params });

// D-150 Conciliacion tributaria
export const conciliacionD150GETAPI = (params) => api.get('/hacienda/d150/conciliacion', { params });
export const reporteD150PDFAPI = (params) => descargarArchivoBlob('/hacienda/d150/reporte/pdf', { params });
export const reporteD150ExcelAPI = (params) => descargarArchivoBlob('/hacienda/d150/reporte/excel', { params });

async function descargarArchivoBlob(url, config) {
  try {
    const res = await api.get(url, { ...config, responseType: 'blob' });
    return res;
  } catch (err) {
    if (err.response?.data instanceof Blob) {
      const texto = await err.response.data.text();
      try { err.response.data = JSON.parse(texto); } catch { /* no era JSON */ }
    }
    throw err;
  }
}

// === Eliminación de Datos de Usuario (Meta / Ley 8968 CR) ===
export const consultarEstadoEliminacionAPI = (codigo) =>
  api.get(`/webhooks/whatsapp/data-deletion/status/${encodeURIComponent(codigo)}`);
export const solicitarEliminacionDatosPublicaAPI = (datos) =>
  api.post('/webhooks/whatsapp/data-deletion/solicitud', datos);
export const eliminarMiCuentaAPI = () => api.delete('/auth/eliminar-cuenta');

export default api;
