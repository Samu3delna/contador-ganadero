const axios = require('axios');

const META_GRAPH_VERSION = process.env.META_GRAPH_VERSION || 'v21.0';
const WHATSAPP_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const WHATSAPP_PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;

function validarUrlDescargaMeta(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error('URL de descarga de Meta inválida');
  }
  if (parsed.protocol !== 'https:') {
    throw new Error('Solo se permite HTTPS para descargas de Meta');
  }
  const host = parsed.hostname.toLowerCase();
  const permitido =
    host === 'graph.facebook.com' ||
    host === 'lookaside.fbsbx.com' ||
    host.endsWith('.fbcdn.net') ||
    host.endsWith('.whatsapp.net') ||
    host.endsWith('.fbsbx.com');
  if (!permitido) {
    throw new Error(`Host no autorizado para descarga de media Meta: ${host}`);
  }
  return parsed.toString();
}

/**
 * Envía un mensaje de texto por WhatsApp usando Meta Cloud API
 */
async function enviarMensajeWhatsApp(telefonoDestino, texto) {
  if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('WHATSAPP_ACCESS_TOKEN y WHATSAPP_PHONE_NUMBER_ID no están configurados');
    }
    console.log(`[WHATSAPP MOCK] Enviar a ${telefonoDestino}: ${texto}`);
    return { mock: true, enviado: true };
  }

  // Normalizar número (solo dígitos)
  const to = String(telefonoDestino).replace(/\D/g, '');

  try {
    const url = `https://graph.facebook.com/${META_GRAPH_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
    const response = await axios.post(
      url,
      {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'text',
        text: { preview_url: false, body: texto },
      },
      {
        headers: {
          Authorization: `Bearer ${WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json',
        },
        timeout: 10000,
        maxRedirects: 0,
      }
    );
    return response.data;
  } catch (error) {
    console.error('❌ Error enviando mensaje WhatsApp:', error.response?.data || error.message);
    throw error;
  }
}

/**
 * Descarga un archivo multimedia (XML, PDF o Imagen) desde los servidores de Meta
 */
async function descargarMediaMeta(mediaId) {
  if (!WHATSAPP_TOKEN) {
    throw new Error('WHATSAPP_ACCESS_TOKEN no configurado');
  }
  if (!/^[a-zA-Z0-9_-]{1,128}$/.test(String(mediaId || ''))) {
    throw new Error('mediaId inválido');
  }

  // 1. Obtener la URL de descarga del recurso
  const metaMediaUrl = `https://graph.facebook.com/${META_GRAPH_VERSION}/${mediaId}`;
  const metaRes = await axios.get(metaMediaUrl, {
    headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}` },
    timeout: 10000,
    maxRedirects: 0,
  });

  const downloadUrl = metaRes.data?.url;
  if (!downloadUrl) {
    throw new Error(`No se pudo obtener URL de descarga para mediaId ${mediaId}`);
  }

  const safeDownloadUrl = validarUrlDescargaMeta(downloadUrl);

  // 2. Descargar el archivo binario con límite de tamaño (5 MB) y sin redirecciones arbitrarias
  const downloadRes = await axios.get(safeDownloadUrl, {
    headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}` },
    responseType: 'arraybuffer',
    timeout: 15000,
    maxRedirects: 0,
    maxContentLength: 5 * 1024 * 1024,
    maxBodyLength: 5 * 1024 * 1024,
  });

  return {
    buffer: Buffer.from(downloadRes.data),
    mimeType: metaRes.data?.mime_type || downloadRes.headers['content-type'],
  };
}

module.exports = {
  enviarMensajeWhatsApp,
  descargarMediaMeta,
  validarUrlDescargaMeta,
};
